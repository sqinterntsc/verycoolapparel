# verycoolapparel — OFF AXIS

Four new on-body 4:5 campaign images. Preserve charcoal shorts, stone merino, moss quarter-zip fleece and sulphur technical shell identity. Extreme wide/fisheye perspective and slight Dutch compositions in rain/snow, kinetic freeze-frame energy and tactile photographic/CG-like materials.

- Shorts: worm's-eye facing wearer, foreshortened thighs in rain.
- Merino: close overhead looking down at wearer gazing up, crossed arms in snow.
- Fleece: lens-on-ground upward chest and snowy cliffs.
- Shell: direct overhead looking up from storm hood, tiny feet below.

Original references: Studio campaign garments. Camera language references Guy Ritchie; cinematic material finish Raoul Marks; outdoor mood Nike ACG/Arc'teryx. No affiliations or copied logos. Realistic adult anatomy, original colours, no baked-in typography or watermarks. Weather effects are creative imagery, not proof of garment manufacture or tested performance.

New files: `products/<slug>/lifestyle-02.webp`. Third gallery slide: Off axis. Preserve Studio and In the elements images and current modal behaviour. Product-specific folder structure retained.
