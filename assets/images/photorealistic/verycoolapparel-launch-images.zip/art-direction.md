# verycoolapparel — launch image art direction

Five final assets: Traverse Short, Contour Merino LS, Altitude Grid Fleece, Strata 3L Shell, and an Alpine Landscape hero.

## Shared product photography
- Square frame; one complete garment floating on a hollow invisible mannequin, no visible support or body.
- Mostly front-facing with gentle dimensional turn, believable gravity, empty neck/waist openings, and full sleeves/hems inside the frame.
- Warm mineral gray seamless studio background, target #eeeae3.
- Eye-level 85 mm product photography; broad upper-left diffused softbox, gentle frontal fill, faint soft floor shadow.
- Crisp true fabric texture, natural wrinkles, restrained hardware, plausible tailored construction. No illustration or plastic CGI look.
- Clear margins, approximately 72–76% garment extent in the frame.
- Original unbranded garment concepts; no text, watermark, or third-party logos.

## Palette and materials
- Traverse Short: charcoal graphite; matte technical woven stretch cloth.
- Contour Merino LS: warm stone; fine-gauge matte wool jersey.
- Altitude Grid Fleece: deep muted moss; fine grid fleece and brushed-knit panels.
- Strata 3L Shell: controlled sulphur/chartreuse, target #d6e342; matte waterproof-shell appearance, charcoal hardware.

Nike ACG and Arc'teryx are market and visual references only. These images do not establish actual manufacture, material composition, performance, or third-party textile certification. In particular, a technical waterproof-shell concept is not proof of GORE-TEX licensing or construction.

## Hero
Wide alpine basin after sunrise, charcoal granite, pale glacier, muted moss vegetation, restrained warm ridge light. Strongest landscape detail on the right; calm left-center/top-left for website copy. No typography baked in, no people, no buildings.

## Delivery boundary
Save the five final images in this photorealistic folder. Leave existing storefront illustrations and HTML/JS image references unchanged. Review the set together before any later website integration.
